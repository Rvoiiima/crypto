problem.txt
    問題や変数の制約が書かれたファイル

generator.py
    encを生成したファイル。python3で正しく動作する。

enc
    暗号化されたフラグを含むファイル。フラグ以外の文字は一切入っていない。

